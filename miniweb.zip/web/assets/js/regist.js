$("#usersuccess").click(function () {
    $("#usersuccess").hide(300);
});
$("#pwdsuccess").click(function () {
    $("#pwdsuccess").hide(300);
});
$("#secpwdsuccess").click(function () {
    $("#secpwdsuccess").hide(300);
});
$("#closs-sucess").click()(function () {
    $("#success").hide(300);
});
$("#registsucess").click()(function () {
    $("#registsucess").hide();
})
function username_check(){
    console.log("checking username");
    var username=$("#form-username").val();
    console.log(username);
    if(username.length<15 && /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/.test(username)){
        //^  　　　　　　 　　　　　　　　　　与字符串开始的地方匹配
        //(?!_)　　　　　　　　　　　　　　　 不能以_开头
       // (?!.*?_$)　　   　　　　　　　　　　不能以_结尾
        //  [a-zA-Z0-9_\u4e00-\u9fa5]+　　  至少一个汉字、数字、字母、下划线
       // $　　　　　　　　　　　　　　　　　与字符串结束的地方匹配
        $("#usersuccess").hide(300);
        console.log("legal username!");
        return true;
    }else{
        $("#usersuccess").show(300);
        console.log("illegal username!");
        return false;
    }

}
function pwd_check(){
    console.log("checking pwd");
    var username=$("#form-username").val();
    var prepassword=$("#form-password").val();
    if(username && username!==prepassword){
        if(prepassword.length>=6 && prepassword.length<15){
            $("#pwdsuccess").hide(300);
            console.log("illegal password!");
            return true;
        }else {
            $("#pwdsuccess").show(300);
            console.log("illegal password!");
            return false;
        }
    }else{
        $("#pwdsuccess").show(300);
        console.log("illegal password!");
        return false;
    }

}
function pwd_doublecheck(){

    var prepassword=$("#form-password").val();
    var secpassword=$("#form-password1").val();
    if(prepassword===secpassword){
        $("#secpwdsuccess").hide(300);
        console.log("legal password!");
        return true;
    }else {
        $("#secpwdsuccess").show(300);
        console.log("different password!");
        return false;
    }


}

function check() {
    var username=$("#username").val();
    var prepassword=$("#prepassword").val();
    var secpassword=$("#secpassword").val();
    console.log("username:"+username+" prepassword:"+prepassword+"secpassword:"+secpassword);
    var CheckUsername=username_check();
    var CheckPassword=pwd_check();
    var DoubleCheckPassword=pwd_doublecheck();
    if(CheckUsername&&CheckPassword&&DoubleCheckPassword){
        $("#success").show(300);
        console.log("regist success!")
        return true;
    }else if(!CheckUsername){
        $("#usersuccess").show(300);
        console.log("illegal username!")
        return false;
    }else if(!CheckPassword){
        $("#pwdsuccess").show(300);
        console.log("illegal password!")
        return false;
    }else if(!DoubleCheckPassword){
        $("#secpwdsuccess").show(300);
        console.log("different password!")
        return false;
    }

}