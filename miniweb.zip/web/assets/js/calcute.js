function average() {
    _table=document.getElementById("table");
    row=_table.rows;

    //alert(row.length-2+"人");
    //alert(table.tBodies[3].rows[2].cells[2].innerHTML);
    sum=0;
    for (i=2;i<row.length;i++) {
        for(j=1;j<5;j++){
            value=parseInt(row[i].cells[j].innerHTML);
            sum+=value;
        }
        row[i].cells[5].innerHTML=sum/4;
        if(sum>=0){
            if (sum/4>=90&&sum/4<=100) {
                row[i].cells[6].innerHTML="A";
            }
            if (sum/4>=80&&sum/4<=89) {
                row[i].cells[6].innerHTML="B";
            }
            if (sum/4>=60&&sum/4<=79) {
                row[i].cells[6].innerHTML="C";
            }
            if (sum/4>=0&&sum/4<=59) {
                row[i].cells[6].innerHTML="D";
            }
        }
        sum=0;
    }


}


function mit(){
    var _table=document.getElementById("table");
    var row=document.createElement("tr");
    _table.tBodies[0].appendChild(row);

    var name=document.createElement("th");
    name.innerHTML=document.getElementById("name").value;
    row.appendChild(name);

    var oop=document.createElement("th");
    oop.innerHTML=document.getElementById("oop").value;
    row.appendChild(oop);

    var java=document.createElement("th");
    java.innerHTML=document.getElementById("java").value;
    row.appendChild(java);

    var web=document.createElement("th");
    web.innerHTML=document.getElementById("web").value;
    row.appendChild(web);

    var db=document.createElement("th");
    db.innerHTML=document.getElementById("db").value;
    row.appendChild(db);

    var sum=document.createElement("th");
    sum.innerHTML="待统计";
    row.appendChild(sum)
    var level=document.createElement("th");
    level.innerHTML="待统计";
    row.appendChild(level);
    average();
}
function average1(oop,java,db,web) {

    _table = document.getElementById("table");
    row = _table.rows;

    console.log("average:"+(oop+java+db+web)/4);
    return parseFloat((parseFloat(oop)+parseFloat(java)+parseFloat(web)+parseFloat(db))/4);
}
function score(sum) {
    if (sum>=90&&sum<=100) {
        return 'A';
    }
    if (sum>=80&&sum<=89) {
        return "B";
    }
    if (sum>=60&&sum<=79) {
        return "C";
    }
    if (sum>=0&&sum<=59) {
        return"D";
    }
    return "ILLEGAL PARAMETER"
}


