package domain;

public class Table {
    private String name;
    private String OOP;
    private String JAVA;
    private String WEB;
    private String DB;
    private String Average;
    private String Grade;

    public Table(){}
    public Table(String name,String OOP,String JAVA,String WEB,String DB,String Average,String Grade){
        this.name=name;
        this.OOP=OOP;
        this.JAVA=JAVA;
        this.WEB=WEB;
        this.DB=DB;
        this.Average=Average;
        this.Grade=Grade;
    }

    public String getName(){
        return this.name;
    }
    public String getGrade(){
        return this.Grade;
    }
    public String getOOP(){
        return this.OOP;
    }
    public String getJAVA(){
        return this.JAVA;
    }
    public String getWEB(){
        return this.WEB;
    }
    public String getDB(){
        return this.DB;
    }
    public String getAverage(){
        return this.Average;
    }

    public void  setName(String name){
        this.name=name;
    }
    public void  setOOP(String OOP){
        this.OOP=OOP;
    }
    public void  setJAVA(String JAVA){ this.JAVA=JAVA; }
    public void  setWEB(String WEB){
        this.WEB=WEB;
    }
    public void  setDB(String DB){
        this.DB=DB;
    }
    public void  setAverage(String average){this.Average=average;}
    public void  setGrade(String grade){this.Grade=grade;}



}
