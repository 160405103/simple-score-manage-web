package dao_impl;

import dao.TableDao;
import domain.Table;
import utils.DataBaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TableDaoImpl implements TableDao {

    @Override
    public boolean getGrade(Table grade) {
        String name=grade.getName();
//这是利用Java JDBC操作数据库的写法
        Connection conn = DataBaseUtil.getConnection();
        String sql = "select * from grade WHERE name=?";
        try{
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ResultSet resultSet = ps.executeQuery();
            if (!resultSet.next()) {
                return false;
            }
            String OOP=resultSet.getString("OOP");
            String JAVA=resultSet.getString("JAVA");
            String WEB=resultSet.getString("WEB");
            String DB=resultSet.getString("DB");
            String Average=resultSet.getString("Average");
            String Grade=resultSet.getString("Grade");

            grade.setOOP(OOP);
            grade.setJAVA(JAVA);
            grade.setWEB(WEB);
            grade.setDB(DB);
            grade.setAverage(Average);
            grade.setGrade(Grade);

        }catch (SQLException e){
            System.out.println(e.toString());
            e.printStackTrace();
        }finally {
            DataBaseUtil.closeConnection(conn);
        }
        return true;
    }

    @Override
    public void saveGrade(Table grade) {
        Connection connection = DataBaseUtil.getConnection();
        String sql = "insert into grade values(?,?,?,?,?,?,?)";
        try{
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1,grade.getName());
            ps.setString(2,grade.getOOP());
            ps.setString(3,grade.getJAVA());
            ps.setString(4,grade.getWEB());
            ps.setString(5,grade.getDB());
            ps.setString(6,grade.getAverage());
            ps.setString(7,grade.getGrade());
            //更新数据库
            ps.executeUpdate();
        }catch (SQLException e){

            e.printStackTrace();
        }finally {
            DataBaseUtil.closeConnection(connection);
        }
    }


    @Override
    public void deleGrade(Table grade) {
        Connection conn = DataBaseUtil.getConnection();
        String sql = " DELETE FROM grade WHERE name=?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);//执行sql语言
            ps.setString(1, grade.getName());
            //ResultSet resultSet = ps.executeQuery();//ResultSet rs 存放的是从数据库中，返回来的数据结果。
            ps.executeUpdate();
        }
        catch (SQLException e){
            System.out.println(e.toString());
            e.printStackTrace();
        }finally {
            DataBaseUtil.closeConnection(conn);
        }

    }

    @Override
    public void modiGrade(Table grade) {
        //https://www.cnblogs.com/Acsii/p/10895755.html
        //修改数据主键冲突
        Connection connection = DataBaseUtil.getConnection();
       // String sql = "UPDATE grade set OOP=?,JAVA=?,WEB=?,DB=?,Average=?,Grade=? ";
        String sql = "replace into grade values(?,?,?,?,?,?,?)";
        try{
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1,grade.getName());
            ps.setString(2,grade.getOOP());
            ps.setString(3,grade.getJAVA());
            ps.setString(4,grade.getWEB());
            ps.setString(5,grade.getDB());
            ps.setString(6,grade.getAverage());
            ps.setString(7,grade.getGrade());
            //更新数据库

            //更新数据库
           int res= ps.executeUpdate();
            if(res>0){

                System.out.println("更新数据成功");

            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            DataBaseUtil.closeConnection(connection);
        }
    }
}
