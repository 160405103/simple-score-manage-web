package dao_impl;

import dao.UserDao;
import domain.UserBean;
import utils.DataBaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by lps on 2017/3/2.
 */
public class UserDaoImpl implements UserDao {
    /**
     * 登陆验证
     *
     * @param user
     * @return true 验证成功 false 验证失败
     */
    public boolean getUser(UserBean user) {
        String username = user.getUsername();
        String password = user.getPassword();
        Connection conn = DataBaseUtil.getConnection();
        String sql = "SELECT  password FROM user WHERE name=?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            System.out.println("进入userdaoimpl" +username);
            ps.setString(1, username);
            ResultSet resultSet = ps.executeQuery();

           // System.out.println(resultSet.getString("name"));
          //中文问题
            //没有该用户，返回false
            if (!resultSet.next()) {
                return false;
            }
            //开始验证用户密码
            String real_password = resultSet.getString("password");
           // System.out.println("密码是"+real_passwor   //密码验证失败
            if (!password.equals(real_password)) {
                return false;
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
            e.printStackTrace();
        } finally {
            DataBaseUtil.closeConnection(conn);
        }
        return true;
    }

    /**
     * 用户名是否已存在
     *
     * @param username
     * @return
     */
    public boolean isUserExist(String username) {
        //连接数据库
        Connection connection = DataBaseUtil.getConnection();
        String sql = "SELECT * FROM user WHERE name=?";
        //访问数据库
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, username);
            //查询是否有该用户
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                return false;
            }
        } catch (SQLException e) {//捕捉异常
            System.out.println(e.toString());
            e.printStackTrace();
        } finally {//关闭数据库
            DataBaseUtil.closeConnection(connection);
        }
        return true;
    }


    /**
     * 新注册用户，存入数据库
     *
     * @param user
     */
    public void saveUser(UserBean user) {
        //得到数据库
        Connection connection = DataBaseUtil.getConnection();
        String sql = "INSERT INTO user (name,password) VALUES(?,?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);


            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            //更新数据库
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtil.closeConnection(connection);
        }
    }
}