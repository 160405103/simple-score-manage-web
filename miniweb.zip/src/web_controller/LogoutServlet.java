package web_controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LogoutServlet extends HttpServlet {
    public void doGet(HttpServletRequest request,
                       HttpServletResponse response) throws ServletException, IOException
    {
        request.setCharacterEncoding("UTF-8");
        HttpSession session=request.getSession(false);
        //false代表：不创建session对象，只是从request中获取。
        if (session==null){
            //response.sendRedirect("index.jsp");
            return;
        }
        session.removeAttribute("user");
        //ServletActionContext.getRequest().getSession().invalidate();
        response.sendRedirect("index.jsp");
        //从定向到index.jsp
    }
    //如果是dopost会出现405错误
    public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
    {		doGet(request, response);	}


}
