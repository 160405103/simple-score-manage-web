package web_controller;

import dao_impl.TableDaoImpl;
import domain.Table;

import javax.servlet.http.HttpServlet;
import java.io.IOException;

public class TableDeleteServlet extends HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        this.doGet(request,response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
       // response.setContentType("text/html;charset=UTF-8");
       // request.setCharacterEncoding("utf-8");
        //response.setCharacterEncoding("UTF-8"); // 注意設置為utf-8否則前端接收到的中文為亂碼
       // response.setContentType("application/json;charset=utf-8");//指定返回的格式为JSON格式
       // PrintWriter out = response.getWriter();
        //String first = request.getParameter("first");           //从前端获取数据first
        //String second = request.getParameter("second");         //从前端获取数据second
        //String result=first+second;
        //String inform=request.getParameter("inform");
        //System.out.println(inform);
        // System.out.println(first);
        //JSONObject ob =new  JSONObject();
       // ob.accumulate("first",second);//添加元素
        //ob.accumulate("second", first);
        //System.out.println(result);                                      //用于测试 ，判断是否成功获取到数据；
        //out.write(result);                                                 //将数据传到前端
       // out.print(ob);
        //out.close();
        //Employee emp=new Employee("","","");
        //JSONObject obj=JSONObject.fromObject(emp);
        //String jsonStr=obj.toString();
        //String name = request.getParameter("name");
        //response.setContentType("text/html;charset=UTF-8");
       // PrintWriter out=response.getWriter();
       // String docType = "<!DOCTYPE html>\n";
        /*out.println(docType +
                "<html>\n" +
                "<head><title>" + name + "</title></head>\n" +
                "<body bgcolor=\"#f0f0f0\">\n" +
                "<h1 align=\"center\">" + name + "</h1>\n");*/
       // out.println("</body></html>");
        String name = request.getParameter("name");
        TableDaoImpl tabledao=new TableDaoImpl();
        Table grade=new Table();
        grade.setName(name);
        tabledao.deleGrade(grade);
        String site = new String("gradeTable.jsp");
        response.setStatus(response.SC_MOVED_TEMPORARILY);
        response.setHeader("Location", site);
        //用来设定一个"态码"。
        //其内容为SC_MOVED_TEMPORARILY，而这个SC_MOVED_TEMPORARILY表示暂时移动目前网页到新地址。
        //此行程序就是通知客户端要更动目前网页的地址。
    }
}
