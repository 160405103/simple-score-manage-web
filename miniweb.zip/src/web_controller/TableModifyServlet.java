package web_controller;

import dao_impl.TableDaoImpl;
import domain.Table;
import org.json.JSONArray;
import org.json.JSONObject;


import javax.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;

public class TableModifyServlet extends HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
       System.out.print("进入modify函数");
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("UTF-8"); // 注意設置為utf-8否則前端接收到的中文為亂碼
        response.setContentType("application/json;charset=utf-8");//指定返回的格式为JSON格式
        String name = request.getParameter("name");
        String oop = request.getParameter("oop");
        String java = request.getParameter("java");
        String web = request.getParameter("web");
        String db = request.getParameter("db");
        String average = request.getParameter("average");
        String grade1 = request.getParameter("grade");
        Table grade = new Table();
        TableDaoImpl tabledao = new TableDaoImpl();
        grade.setName(name);
        grade.setOOP(oop);
        grade.setJAVA(java);
        grade.setWEB(web);
        grade.setDB(db);
        grade.setAverage(average);
        grade.setGrade(grade1);
        tabledao.modiGrade(grade);

        JSONObject jo=new JSONObject();
        jo.put("name",name);
        jo.put("oop",oop);
        jo.put("java",java);
        jo.put("web",web);
        jo.put("db",db);
        jo.put("average",average);
        jo.put("grade",grade1);
        JSONArray json=new JSONArray();
        json.put(jo);
     System.out.print("修改后的json对象"+json);
         String str = json.toString();
       //JSONObject jo = JSONObject.fromObject(map);//将java对象转换为json对象
        System.out.print("修改后的json对象字符串"+str);

       //String str = jo.toString();//将json对象转换为字符串

        PrintWriter out = response.getWriter();

        out.write(str);

     /*String site = new String("gradeTable.jsp");
     response.setStatus(response.SC_MOVED_TEMPORARILY);
     response.setHeader("Location", site);*/
    }
}

