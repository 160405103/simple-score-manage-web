package web_controller;

import dao_impl.UserDaoImpl;
import domain.UserBean;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class RegistServlet extends HttpServlet {
    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)throws ServletException,IOException{
        request.setCharacterEncoding("UTF-8");
        String username=request.getParameter("form-username");
        String password=request.getParameter("form-password");
        UserBean user = new UserBean();
        user.setUsername(username);
        user.setPassword(password);
        System.out.print(username);
        System.out.print(password);
        UserDaoImpl dao = new UserDaoImpl();
        dao.saveUser(user);
        request.setAttribute("info", "注册成功");
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}
