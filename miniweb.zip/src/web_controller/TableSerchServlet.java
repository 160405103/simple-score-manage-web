package web_controller;

import dao_impl.TableDaoImpl;
import domain.Table;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class TableSerchServlet extends HttpServlet {
    public void doPost(HttpServletRequest request,
                       HttpServletResponse response) throws ServletException, IOException {
        System.out.print("进入serch函数");
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("UTF-8"); // 注意設置為utf-8否則前端接收到的中文為亂碼
        //response.setContentType("application/json;charset=utf-8");//指定返回的格式为JSON格式
        String name = request.getParameter("name");
        Table grade = new Table();
        TableDaoImpl tabledao = new TableDaoImpl();
        grade.setName(name);
        tabledao.getGrade(grade);
        JSONObject jo=new JSONObject();
        jo.put("name",grade.getName());
        jo.put("oop",grade.getOOP());
        jo.put("java",grade.getJAVA());
        jo.put("web",grade.getWEB());
        jo.put("db",grade.getDB());
        jo.put("average",grade.getAverage());
        jo.put("grade",grade.getGrade());
        JSONArray json=new JSONArray();
        json.put(jo);
        System.out.print("serachjson对象"+json);
        //JSONArray json=new JSONArray();
        String str = json.toString();
        System.out.print("serachjson对象字符串"+str);
       /* JSONObject jo = JSONObject.fromObject(grade);//将java对象转换为json对象
        String str = jo.toString();//将json对象转换为字符串
        //System.out.print(jo);*/
        PrintWriter out = response.getWriter();

        out.write(str);
    }
}
