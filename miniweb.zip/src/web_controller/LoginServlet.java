package web_controller;

import dao_impl.UserDaoImpl;
import domain.UserBean;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by lps on 2017/3/3.
 */
public class LoginServlet extends HttpServlet {
    public void doPost(HttpServletRequest request,
                       HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        String username = request.getParameter("form-username");
        String password = request.getParameter("form-password");
        System.out.print(username);
        System.out.print(password);
        UserBean user = new UserBean();
        user.setUsername(username);
        user.setPassword(password);
        UserDaoImpl dao = new UserDaoImpl();
        if (dao.getUser(user)) {
            Cookie nameCookie = new Cookie("username", username);
            //设置Cookie的有效期:3天
            nameCookie.setMaxAge(60*60*24*3);
            Cookie pwdCookie = new Cookie("password", password);
            pwdCookie.setMaxAge(60*60*24*3);
            response.addCookie(nameCookie);
            response.addCookie(pwdCookie);

            //设置页面显示信息
            request.setAttribute("info", "登陆成功!欢迎您的访问！");
            //用户信息存入session，供当前访问使用
            request.getSession().setAttribute("user",user);
            //请求转发（带信息，而重定向是丢失信息的）
            request.getRequestDispatcher("gradeTable.jsp").forward(request, response);
        } else {
            request.setAttribute("info", "用户名或密码错误");
            request.getRequestDispatcher("message.jsp").forward(request, response);
            /*取得一个RequestDispatcher，一个请求分发器对象，它的方法fdorward(request,response)作用是将请求转发到login_success.jsp，request封装了请求信息，response封装了响应信息。注意是forward方式，这种方式只转发请求，不产生新的request对象。 */
        }

    }
}