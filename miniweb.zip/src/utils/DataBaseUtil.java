package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseUtil {
    public DataBaseUtil() {
    }

    /**
     * 开启数据库，得到数据库对象
     *
     * @return 数据库对象
     */
    public static Connection getConnection() {
        Connection connection = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String sqle = "jdbc:mysql://localhost:3306/login?useUnicode=true&characterEncoding=utf8";
            //数据库在存放项目数据的时候会先用UTF-8格式将数据解码成字节码，然后再将解码后的字节码重新使用GBK编码存放到数据库中。
            //在从数据库中取数据的时候，数据库会先将数据库中的数据按GBK格式解码成字节码，然后再将解码后的字节码重新按UTF-8格式编码数据，最后再将数据返回给客户端。
            connection = DriverManager.getConnection(sqle, "root", "li261018");
            return connection;
        } catch (ClassNotFoundException var2) {
            var2.printStackTrace();
        } catch (SQLException var3) {
            var3.printStackTrace();
        }
        return connection;
    }

    /**
     * 关闭数据库
     *
     * @param connection 数据库对象
     */
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException var2) {
                var2.printStackTrace();
            }
        }

    }
}