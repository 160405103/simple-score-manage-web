package dao;

import domain.UserBean;

/**
 * Created by lps on 2017/3/2.
 */
public interface UserDao {
    //用户登陆验证
    public boolean getUser(UserBean user);
    //某用户名是否已存在
    public boolean isUserExist(String username);
    //将用户存入数据库
    public void saveUser(UserBean user);
}
