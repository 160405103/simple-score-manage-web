package dao;
import domain.Table;

public interface TableDao {
    public boolean getGrade(Table grade);//得到grade某一个用户的所有信息，存在这个对象里 查
    public void saveGrade(Table grade); //增加
    public void deleGrade(Table grade);//删除
    public void modiGrade(Table grade);//修改


}
